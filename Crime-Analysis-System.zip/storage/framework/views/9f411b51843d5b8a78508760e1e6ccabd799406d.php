<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>C·A·S | <?php echo $__env->yieldContent('title'); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta name="user_id" content="<?php echo e(Auth::check() ? Auth::user()->id : ''); ?>">
        
        <meta content="C·A·S - Crime Analysis System" name="description" />
        <meta content="C·A·S" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('admin/assets/images/favicon.ico')); ?>">

        <!-- App css -->
        <link href="<?php echo e(asset('admin/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('admin/assets/css/icons.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('admin/assets/css/metismenu.min.css')); ?>" rel="stylesheet" type="text/css" />
        
        <link href="<?php echo e(asset('admin/assets/css/style_dark.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('admin/plugins/jquery-toastr/jquery.toast.min.css')); ?>" rel="stylesheet" />
        
        <?php echo $__env->yieldContent('styles'); ?>

        <script src="<?php echo e(asset('admin/assets/js/modernizr.min.js')); ?>"></script>
    </head>

    <body>
        <!-- Begin page -->
        <div id="wrapper">
            <!-- ========== Sidebar ========== -->
            <div class="left side-menu side-menu-sm">
                <div class="slimscroll-menu" id="remove-scroll">
                    <!-- LOGO -->
                    <div class="topbar-left">
                        <a href="<?php echo e(route('dashboard')); ?>" class="logo">
                            <span>
                                <img src="<?php echo e(asset('admin/assets/images/logo_light.png')); ?>" alt="" height="50">
                            </span>
                            <i>
                                <img src="<?php echo e(asset('admin/assets/images/logo_sm_light.png')); ?>" alt="" height="50">
                            </i>
                        </a>
                    </div>

                    <?php echo $__env->make('admin.includes.user-box', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php echo $__env->make('admin.includes.side-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <div class="clearfix"></div>
                </div>
            </div>

            <!-- ============================================================== -->
            <!-- Contenido dinamico de la pagina -->
            <!-- ============================================================== -->

            <div class="content-page">
                
                <?php echo $__env->make('admin.includes.top-bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class="content">
                    <div class="container-fluid">

                        <?php echo $__env->yieldContent('content'); ?>

                    </div>
                </div>

                <?php echo $__env->make('admin.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </div>
        </div>

        <!-- jQuery  -->
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/js/popper.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/js/metisMenu.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/js/waves.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/js/jquery.slimscroll.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/plugins/jquery-toastr/jquery.toast.min.js')); ?>"></script>

        <!-- Dashboard -->
        

        <!-- App js -->
        <script src="<?php echo e(asset('admin/assets/js/jquery.core.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/js/jquery.app.js')); ?>"></script>
        <script src="<?php echo e(asset('js/resources.js')); ?>"></script>
        
        <script type="text/javascript">
            <?php if(Session::has('success')): ?>
                successAlert('¡Bien Hecho!', '<?php echo e(Session::get('success')); ?>');
            <?php endif; ?>
        </script>

        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>