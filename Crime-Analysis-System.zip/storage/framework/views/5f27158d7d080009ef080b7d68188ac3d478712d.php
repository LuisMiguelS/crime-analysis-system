<?php $__env->startSection('title', 'Consultar Status Vehículo'); ?>
<?php $__env->startSection('subtitle', 'Consulta el perfil criminal de una persona'); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="row">
    	<div class="col-md-12">
        	<div class="card-box">
        		<h4 class="header-title mb-4">INGRESA LA INFORMACIÓN NECESARIA PARA PROSEGUIR</h4>
        		<p class="text-muted font-14 m-b-20">
                    Ingresando el número de la placa del vehículo en cuestión, podrás consultar el status y el historial con todos los incidentes sucedidos (si aplica) a dicho vehículo.
                </p>
	        	
	        	<div class="card-body">
	                <form method="POST" action="<?php echo e(route('see_vehicle_status')); ?>">
                        <?php echo csrf_field(); ?>

	                    <div class="form-group">
	                        <label for="userName">Número de Placa<span class="text-danger"> *</span></label>
	                        <input type="text" name="placa" parsley-trigger="change" required
	                               placeholder="Ingresa el número de placa" class="form-control" id="placa" autocomplete="off">
	                    </div>

	                    <div class="form-group text-right m-b-0">
	                        <button class="btn btn-custom waves-effect waves-light" type="button" id="consultar">
	                            <i class="fa fa-search m-r-5"></i>
	                            <span>Consultar</span>
	                        </button>
	                    </div>
	                </form>
	            </div>
        	</div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

	<script type="text/javascript">
        $(document).ready(function() {
			
            $('#consultar').click(function() {

                var numero_placa = $('#placa').val();

                if(!numero_placa.length)
                {
				    dangerAlert('¡Oh, espera!', 'Debes ingresar un número de placa para proseguir.');
                }

                else
                {
                	$('form').submit();
                	/*$.ajax({
			            type: 'POST',
			            headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
			            url: '<?php echo e(route('see_vehicle_status')); ?>',
			            data: { 'placa': numero_placa },
			            success: function( response ) {
			                console.log(response);
			            }
			        });*/
                }
            });
        });
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>