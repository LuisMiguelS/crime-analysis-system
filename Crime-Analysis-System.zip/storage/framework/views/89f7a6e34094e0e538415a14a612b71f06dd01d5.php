<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('subtitle', '¡Bienvenido al Admin Panel C·A·S!'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12">
        <div class="card-box">
            <h4 class="header-title mb-4">ESTADÍSTICAS DEL AÑO EN CURSO</h4>

            <div class="row text-center">
                <div class="col-sm-6 col-lg-6 col-xl-3">
                    <div class="card-box widget-flat border-secondary bg-secondary text-white">
                        <i class="fa fa-car"></i>
                        <h3 class="m-b-10"><?php echo e($cant_accidentes[0]->cant); ?></h3>
                        <p class="text-uppercase m-b-5 font-13 font-600">Cantidad de Accidentes Automovilístico</p>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6 col-xl-3">
                    <div class="card-box bg-warning widget-flat border-warning text-white">
                        <i class="fa fa-warning"></i>
                        <h3 class="m-b-10"><?php echo e($cant_incidentes[0]->cant); ?></h3>
                        <p class="text-uppercase m-b-5 font-13 font-600">Cantidad de Incidentes Automovilístico</p>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6 col-xl-3">
                    <div class="card-box widget-flat border-danger bg-danger text-white">
                        <i class="fa fa-times"></i>
                        <h3 class="m-b-10"><?php echo e($cant_crimenes[0]->cant); ?></h3>
                        <p class="text-uppercase m-b-5 font-13 font-600">Cantidad de Crímenes Ocurridos</p>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6 col-xl-3">
                    <div class="card-box bg-primary widget-flat border-primary text-white">
                        <i class="fa fa-expeditedssl"></i>
                        <h3 class="m-b-10"><?php echo e($cant_reclusos[0]->cant); ?></h3>
                        <p class="text-uppercase m-b-5 font-13 font-600">Cantidad de Personas Apresadas </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="row">
    <div class="col-lg-6">
        <div class="card-box">
            <h4 class="header-title">Estadísticas de Crímenes del año anterior <span class="text-muted">(<?php echo e(date('Y') - 1); ?>)</span></h4>
            <canvas id="myChart" height="250"></canvas>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="card-box">
            <h4 class="header-title">Estadísticas de crímenes por tipo de arma del año anterior <span class="text-muted">(<?php echo e(date('Y') - 1); ?>)</span> Expresado en %</h4>
            <canvas id="oilChart" height="250"></canvas>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card-box">
            <h4 class="header-title">Estadísticas de crímenes por localidades del año anterior <span class="text-muted">(<?php echo e(date('Y') - 1); ?>)</span></h4>
            <div id="crimenes_ubicacion" height="200"></div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card-box">
            <h4 class="header-title mb-3">Personas apresadas recientemente</h4>
            <div class="table-responsive">
                <table class="table table-hover table-centered m-0">
                    <thead>
                    <tr>
                        <th>Profile</th>
                        <th>Nombre</th>
                        <th>Acusado por:</th>
                        <th>Prisión</th>
                        <th>Sentencia</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $reclusos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recluso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <img src="<?php echo e(asset('images/'.$recluso->id.'.jpg')); ?>" alt="contact-img" title="contact-img" class="rounded-circle thumb-sm" />
                            </td>

                            <td>
                                <h5 class="m-0 font-weight-normal"><?php echo e($recluso->nombre); ?></h5>
                                <p class="mb-0 text-muted"><small>Apresado desde el <?php echo e($recluso->created_at); ?></small></p>
                            </td>

                            <td>
                                <?php echo e(ucfirst($recluso->titular)); ?>

                            </td>

                            <td>
                                <i class="mdi mdi-map-marker text-default"></i> <?php echo e($recluso->prision); ?>

                            </td>

                            <td>
                                <i class="mdi mdi-calendar-clock text-info"></i> <?php echo e($recluso->years); ?> año(s)
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <div class="card-box">
            <h4 class="header-title mb-3">últimas alertas de personas peligrosas</h4>
            <div class="table-responsive">
                <table class="table table-hover table-centered m-0">
                    <thead>
                    <tr>
                        <th>Profile</th>
                        <th>Nombre</th>
                        <th>Alerta</th>
                        <th>Status</th>
                        <th>Fecha Emisión</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if($alerts): ?>
                        <?php $__currentLoopData = $alerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <img src="<?php echo e(asset('images/'.$alert->person_id.'.jpg')); ?>" title="contact-img" class="rounded-circle thumb-sm" />
                                </td>

                                <td>
                                    <h5 class="m-0 font-weight-normal"><?php echo e($alert['person']['nombres']); ?></h5>
                                    
                                </td>

                                <td><?php echo e($alert['titular']); ?></td>

                                <td><?php echo $alert['status_person']; ?></td>

                                <td>
                                    <i class="mdi mdi-calendar-clock text-info"></i> <?php echo e($alert['created_at']); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card-box">
            <h4 class="m-t-0 header-title">Cantidad de prisioneros por año</h4>

            <div id="donut-chart">
                <div id="donut-chart-container" class="flot-chart mt-5" style="height: 340px;">
                    <div class="inbox-widget slimscroll" style="max-height: 370px;">
                        <?php if($prisioneros_yyear): ?>
                            <?php $__currentLoopData = $prisioneros_yyear; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prisionero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a>
                                <div class="inbox-item">
                                    <p class="inbox-item-author">Cant. de Prisioneros: <?php echo e($prisionero->cant); ?></p>
                                    <p class="inbox-item-text"><i class="fa fa-calendar text-success"></i> <?php echo e($prisionero->yyear); ?></p>
                                    <p class="inbox-item-date">C·A·S</p>
                                </div>
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    
<?php $__env->stopSection(); ?>


<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/assets/css/c3.min.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.bundle.min.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('admin/assets/js/d3.v5.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('admin/assets/js/c3.min.js')); ?>"></script>

    <script>
        
        Chart.defaults.global.defaultFontFamily = "Arial Narrow";
        Chart.defaults.global.defaultFontSize = 15;


        
        var ctx = document.getElementById("myChart").getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: [
                    <?php
                        foreach ($crimenes as $crimen)
                        {
                            echo "'$crimen->crimen',";
                        }
                    ?>
                ],
                datasets: [{
                    data: [
                        <?php
                            foreach ($crimenes as $crimen)
                            {
                                echo "'$crimen->total',";
                            }
                        ?>
                    ],
                    backgroundColor: [
                        '#263238',
                        '#BF360C',
                        '#0D47A1',
                        '#004D40'
                    ],
                    borderColor: [
                        '#263238',
                        '#BF360C',
                        '#0D47A1',
                        '#004D40'
                    ],
                    borderWidth: 2
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                },

                title: {
                    display: true,
                    text: 'Cantidad de Crímenes'
                },

                legend: {
                    display: false
                }
            }
        });

        
        
        var oilCanvas = document.getElementById("oilChart");

        var oilData = {
            labels: [
                <?php
                    foreach ($crimenes_arma as $crimen)
                    {
                        echo "'$crimen->arma',";
                    }
                ?>
            ],
            datasets: [
                {
                    data: [
                        <?php
                            foreach ($crimenes_arma as $crimen)
                            {
                                echo "'$crimen->total',";
                            }
                        ?>
                    ],
                    backgroundColor: [
                        "#880E4F",
                        "#00B8D4",
                        "#FFAB00",
                        "#3E2723",
                        "#b71c1c"
                    ]
                }]
        };

        var pieChart = new Chart(oilCanvas, {
            type: 'pie',
            data: oilData
        });


        
        var chart = c3.generate({
            bindto: '#crimenes_ubicacion',
            data: {
                x: 'x',
                columns: [
                ['x', 
                    <?php
                        foreach ($crimenes_ubicacion as $crimen)
                        {
                            echo "'$crimen->ubicacion',";
                        }
                    ?>
                ],
                ['Cant. de crímenes:', 
                    <?php
                        foreach ($crimenes_ubicacion as $crimen)
                        {
                            echo "'$crimen->total',";
                        }
                    ?>
                ],
              ],
              // type: 'bar'
            },
            /*bar: {
                width: {
                    ratio: 0.5 // this makes bar width 50% of length between ticks
                }
                // or
                //width: 100 // this makes bar width 100px
            },
            type: 'bar',*/
            axis: {
                x: {
                    type: 'category'
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>