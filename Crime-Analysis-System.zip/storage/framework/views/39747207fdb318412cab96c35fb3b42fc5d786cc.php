<?php $__env->startSection('title', 'Perfil Criminal'); ?>
<?php $__env->startSection('subtitle', '¡Perfil criminal generado!'); ?>

<?php $__env->startSection('content'); ?>

	<div class="row card">
		<div class="col-md-12">
			<h1 class="text-center header-title mb-4 mt-4 text-custom" style="font-size: 25px;">Perfil Criminal C·A·S
				<a href="<?php echo e(route('crime_profile')); ?>"><i class="fa fa-mail-reply text-info" title="Consultar Nuevamente"></i></a></h1>
			</h1>
		</div>

		<div class="col-md-12 card-body">
			<div class="row">
				<div class="col-md-4 text-center">
					<div class="criminal_profile">
						<img class="img img-responsive" src="<?php echo e(asset('images/'.$person->id.'.jpg')); ?>" width="100%" height="auto">
					</div>

					<h4>Status:</h4>
					<?php if(isset($danger_person)): ?>
						<?php if(!$danger_person->atrapado): ?>
							<h3 class="text-danger"><?php echo strtoupper($danger_person->status_person); ?></h3>
							<span class="text-muted" style="font-size: 15px;">
								<?php echo e(strtoupper($danger_person->titular)); ?>

							</span>
						<?php else: ?>
							<h3 class="text-success">SIN ALERTA</h3>
						<?php endif; ?>
					<?php else: ?>
						<h3 class="text-success">SIN ALERTA</h3>
					<?php endif; ?>

					<h4 class="mt-4">Última Condena: <?php echo $ultima_condena->status_carcel; ?></h4>
					<?php if(isset($prision)): ?>
						<p>
							<i class="mdi mdi-map-marker text-default"></i> <?php echo e($prision->nombre_prision); ?> - <?php echo e($prision->direccion); ?><br>
							<i class="mdi mdi-calendar-clock text-danger"></i> <?php echo e($ultima_condena->years); ?> año(s) de prisión <br>
							<i class="mdi mdi-timer-sand text-primary"></i>
								<strong class="text-danger"> [<?php echo e($ultima_condena->created_at); ?>] </strong> -
								<strong class="text-success"> [<?php echo e($ultima_condena->fecha_salida); ?>] </strong>
						</p>
					<?php else: ?>
						<strong class="text-success">NINGUNA</strong>
					<?php endif; ?>
				</div>

				<div class="col-md-7">
					<h3>· Información Básica de: <?php echo e($person->nombres); ?></h3>

					<div class="row">
						<div class="form-group col-md-4">
							<label>Nombres:</label>
							<input class="form-control" type="text" id="nombres" disabled="" readonly="" value="<?php echo e($person->nombres); ?>">
						</div>

						<div class="form-group col-md-4">
							<label>Apellidos:</label>
							<input class="form-control" type="text" id="apellidos" disabled="" readonly="" value="<?php echo e($person->apellidos); ?>">
						</div>

						<div class="form-group col-md-4">
							<label>Alías:</label>
							<input class="form-control" type="text" id="alias" disabled="" readonly="" value="<?php echo e($person->alias); ?>">
						</div>

						<div class="form-group col-md-3">
							<label>Cédula:</label>
							<input class="form-control" type="text" id="cedula" disabled="" readonly="" value="<?php echo e($person->identificacion); ?>">
						</div>

						<div class="form-group col-md-3">
							<label>Fecha de Nac.:</label>
							<input class="form-control" type="text" id="fecha_nac" disabled="" readonly="" value="<?php echo e($person->fecha_nac); ?>">
						</div>

						<div class="form-group col-md-3">
							<label>Edad:</label>
							<input class="form-control" type="text" id="edad" disabled="" readonly="" value="<?php echo e($person->edad); ?>">
						</div>

						<div class="form-group col-md-3">
							<label>Sexo:</label>
							<input class="form-control" type="text" id="sexo" disabled="" readonly="" value="<?php echo e($person->sexo); ?>">
						</div>

						<div class="form-group col-md-4">
							<label>Estado Civil:</label>
							<input class="form-control" type="text" id="estado_civil" disabled="" readonly="" value="<?php echo e($person->estado_civil); ?>">
						</div>

						<div class="form-group col-md-6">
							<label>Lugar de Residencia:</label>
							<input class="form-control" type="text" id="residencia" disabled="" readonly="" value="<?php echo e($person->residencia); ?>">
						</div>
					</div>					

					<h3 class="mt-5">· Historial de Condenas</h3>
					
					<ul>
						<?php if(isset($prision)): ?>
							<?php $__currentLoopData = $person->recluses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recluse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li>
									Apresado(a) por <?php echo e($recluse->titular); ?> el <strong class="text-danger"><?php echo e($recluse->created_at); ?></strong>. Sentenciado(a) con una condena de <strong><?php echo e($recluse->years); ?> año(s)</strong>.

									
									<?php if($recluse->status == 'e' or $recluse->status == 'c'): ?>
										El recluso salió de prisión el <strong class="text-success"><?php echo e($recluse->fecha_salida); ?></strong>.
									<?php endif; ?>
								</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
							<li>Ningún historial de prisión.</li>
						<?php endif; ?>
					</ul>

					<h3 class="mt-5">· Historial de Alertas Peligrosas</h3>
					
					<ul>
						<?php if(isset($danger_person)): ?>
							<?php $__currentLoopData = $notificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li>
									<?php echo $notificacion->status_person; ?> <?php echo e($notificacion->titular); ?> el <strong class="text-danger"><?php echo e($notificacion->created_at); ?></strong>.

									<?php if($notificacion->atrapado): ?>
										Fue <strong class="text-success">atrapado(a)</strong> el <strong class="text-success"><?php echo e($notificacion->created_at); ?></strong>.
									<?php endif; ?>
								</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
							<li>Ningún historial de alertas peligrosas.</li>
						<?php endif; ?>
					</ul>

					<h3 class="mt-5">· Antecedentes Criminales</h3>
				</div>

				<div class="col-md-12">
					<table id="datatable-buttons" class="table table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>Titular</th>
                                <th>Descripción</th>
                                <th>Crimen</th>
                                <th>Fecha</th>
                            </tr>
                        </thead>

                        <tbody>
                        	<?php $__currentLoopData = $person->crimes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            <tr>
	                                <td>Acusado(a) por: <?php echo e(ucfirst($crime['pivot']->titular)); ?></td>
	                                <td><?php echo e(ucfirst($crime['pivot']->descripcion)); ?></td>
	                                <td><?php echo e(ucwords($crime->nombre_crimen)); ?></td>
	                                <td><?php echo e(date_format($crime['pivot']->created_at, 'd/m/Y')); ?></td>
	                            </tr>
	                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
	                </table>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
	<link href="<?php echo e(asset('admin/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('admin/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('admin/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />

    <style type="text/css">
    	.criminal_profile
    	{
			box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
			border: solid 2px #02c0ce;
			width: 250px;
			height: auto;
			display: block;
			margin: 0 auto;"
    	}
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <script src="<?php echo e(asset('admin/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>

    <script src="<?php echo e(asset('admin/plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/datatables/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/datatables/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/datatables/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/datatables/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/datatables/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/datatables/buttons.print.min.js')); ?>"></script>
	
	<script type="text/javascript">

		var table = $('#datatable-buttons').DataTable({
            lengthChange: false,
            buttons: ['copy', 'excel', 'pdf'],
            "responsive": true,
            "lengthMenu": [[5, 10, 15, 20], [5, 10, 15, 20]],
            "language": {
                "sProcessing": "Procesando...",
                "sLengthMenu": "Mostrar _MENU_ registros",
                "sZeroRecords": "No se encontraron resultados",
                "sEmptyTable": "Ningún dato disponible en esta tabla",
                "sInfo": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                "sInfoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
                "sInfoFiltered": "(filtrado de un total de _MAX_ registros)",
                "sInfoPostFix": "",
                "sSearch": "Buscar:",
                "sUrl": "",
                "sInfoThousands": ",",
                "sLoadingRecords": "Cargando...",
                "oPaginate": {
                    "sFirst": "Primero",
                    "sLast": "Último",
                    "sNext": "Siguiente",
                    "sPrevious": "Anterior"
                },
                "oAria": {
                    "sSortAscending": ": Activar para ordenar la columna de manera ascendente",
                    "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                }
            }
        });

        table.buttons().container()
            .appendTo('#datatable-buttons_wrapper .col-md-6:eq(0)');
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>