$(document).ready(function () {
    console.log('dashboard');
});