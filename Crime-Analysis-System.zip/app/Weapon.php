<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Weapon extends Model
{
    protected $protected = [
    	'nombre_arma'
    ];
}
