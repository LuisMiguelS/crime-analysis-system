<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TempCrime extends Model
{
    //
}
