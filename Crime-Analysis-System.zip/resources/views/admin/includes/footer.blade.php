<footer class="footer text-right">
    Copyright © 2018 C·A·S. All rights reserved.
</footer>